<?php
session_start();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
  <title>RTS</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <script src="js/libs.min.js" type="text/javascript"></script>
    <script src="js/createjs.min.js"></script>
    <script src="js/gsap.min.js"></script>
    <link id="callCss" rel="stylesheet" href="css/main.css" type="text/css" media="screen" charset="utf-8" />
<body>

  <header>
    <div class="container">
      <div class="row">
        <div class="col-3 center-logo">
          <a href="index.php"><h1 class="logo">Miracle</h1></a>
        </div>
        <div class="col-9 centering-nav">
            <ul class="nav justify-content-end">
              <li class="nav-item">
                <a class="nav-link" href="index.php">Main</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="shop.php">Catalog</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="profile.php">Profile</a>
              </li>
            </ul>
        </div>
      </div>
    </div>
  </header>
 <!--  <canvas id="projector"></canvas> -->
<div class="wrapper">
  <div class="content">

<div class="main-background">
  <div class="container">
    <div class="row">
      <div class="col-6 siteName">
          <div class="siteNameText">
            <h1 class="siteNameTop">Miracle</h1>
            <h1 class="siteNameBottom">market</h1>
          </div>
      </div>
      <div class="col-6 logButtons">
        <div class="loginButtons">
          <a class="commonloginButtonstyles logSeller" href="login.php">Enter the market</a>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="infBlock">
  <div class="container centeringCard">
      <div class="card-deck mb-3 text-center">
          <div class="card1 card mb-4 shadow-sm cart-x " id="hovercard">
           <div class="classForHovere">
            <div class="card-header">
              <h4 class="my-0 font-weight-normal">Safety</h4>
              </div>
              <div class="card-body">
              <div class="cardImg img-1 img-settings"></div>
              <div class="imgTitle">All your purchases are protected by the service</div>
              </div>


           </div>

          </div>
          <div class="card2 card mb-4 shadow-sm cart-x " id="hovercard">
              <div class="classForHovere">
            <div class="card-header">
              <h4 class="my-0 font-weight-normal">Delivery</h4>
            </div>
            <div class="card-body">
              <div class="cardImg img-2 img-settings"></div>
              <div class="imgTitle">Fast and high quality delivery of goods</div>
              </div>
            </div>
            </div>
            <div class="card3 card mb-4 shadow-sm cart-x" id="hovercard">
              <div class="classForHovere">
            <div class="card-header">
              <h4 class="my-0 font-weight-normal">Support</h4>
            </div>
            <div class="card-body">
              <div class="cardImg img-3 img-settings"></div>
              <div class="imgTitle">Quick bug fix, solving your problems with the service</div>
              </div>
            </div>
            </div>
  </div>
</div>







</div>



</body>
<script src="js/prekrasno.js" type="text/javascript"></script>
</body>
</html>
