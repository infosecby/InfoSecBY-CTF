

// function_name();

// ScrollReveal().reveal('.card');