$(document).ready(function() {
/*----------------------------------------
Upload btn
------------------------------------------*/
var SITE = SITE || {};
 
SITE.fileInputs = function() {
  var $this = $(this),
      $val = $this.val(),
      valArray = $val.split('\\');
};
 

$('.file-wrapper input[type=file]').bind('change focus click', SITE.fileInputs);

function readURL(input) {
  if (input.files && input.files[0]) {
    var reader = new FileReader();
    var tmppath = URL.createObjectURL(event.target.files[0]);

    reader.onload = function (e) {
      $('#img-uploaded').attr('src', e.target.result);
      $('input.img-path').val(tmppath);
    }

    reader.readAsDataURL(input.files[0]);
  }
}

$(".uploader").change(function(){
  readURL(this);
});

//SHOP

window.onload = function(){
 
    var cartItems = {
        picture: "",
        productName: "",
        quantity: "",
        price: "",
        closePicture: "../img/Close-128.png"
    };
    
    var cart = document.getElementById('cart');
    var appleButton = document.getElementById('apple');
    // var bananaButton = document.getElementById('banana');
    // var pineappleButton = document.getElementById('pineapple');
    var items = document.getElementsByClassName('AddToCart');
    var counter = 0;
    var cartIcon = document.getElementById('cartIcon');
    var cartChild = document.getElementById('cartChild');
    var totalPrice = document.getElementById('totalPrice');
    
    
    appleButton.onclick  = addToCart; 
    // bananaButton.onclick = addToCart;
    // pineappleButton.onclick = addToCart; 
    for (var i = 0; i < items.length; i++) {
     items[i].onclick = addToCart;
    }
    var items2 = document.getElementsByClassName('producCart');
    for (var i = 0; i<items2.length; i++) {
        console.log("heh");
    }
    
    function addToCart(){
        cartItems.picture = this.parentNode.children[1].getAttribute('src');
        cartItems.productName = this.parentNode.children[0].innerHTML;
        cartItems.quantity = this.parentNode.children[3].children[0].value;
        cartItems.price = this.parentNode.children[2].children[0].innerHTML; 
        console.log(cartItems);
        console.log(cartItems.productName);
        
        
        var div = document.createElement('div');
        div.classList.add("cartElement");
        var img = document.createElement('img');
        img.classList.add("productPicture");
        img.setAttribute("src",cartItems.picture);
        var h4 = document.createElement('h4');
        h4.innerHTML = cartItems.productName;
        var span1 = document.createElement('span');
        span1.innerHTML = cartItems.quantity + " kg";
        var div2 = document.createElement('div');
        div2.classList.add("price");
        div2.innerHTML = cartItems.price*cartItems.quantity + " $";
        var img2 = document.createElement('img');
        img2.classList.add("close");
        img2.setAttribute("src",cartItems.closePicture);
            
        //console.log(div2);
        
        cart.insertBefore(div, cartChild);
        div.appendChild(img);
        div.appendChild(h4);
        div.appendChild(span1);
        div.appendChild(div2);
        div.appendChild(img2);
        
        
        var close = document.getElementsByClassName('close');
        for( i = 0; i < close.length; i++){   
            close[i].onclick = function(){
                var parent = this.parentNode.parentNode;
                var child = this.parentNode;
                parent.removeChild(child)
                counter--;
                circle.innerHTML = counter;
                totalSum()
            }
        }
        
        var circle = document.getElementById('circle');
        counter++;
        circle.innerHTML = counter;
        
        function totalSum(){
            var summ = 0
            var elementsPrice = document.getElementsByClassName('price');      
            for(i = 0; i < elementsPrice.length; i++){
                summ += parseInt(elementsPrice[i].innerHTML);
                totalPrice.innerHTML = summ + " $";
            }
            if(elementsPrice.length == 0){
                summ = 0;
                totalPrice.innerHTML = summ + " $";
            }
        }
        totalSum()
        //console.log(elementsPrice[i]);
    }
    
    cartIcon.onclick = function openCart(){
        if (cart.style.display == "inline-block"){
            cart.style.display = "none";
        }
        else{
            cart.style.display = "inline-block";
        }
    }
  
    
    
}












// $('.menu-btn').bind('click', function(e){
// 		$('.header-mobile').toggleClass('content-active');//Check for iphone, not for prod (сдвиг хедера (отдельно))
// 		$('.menu').toggleClass('menu-active'); // Выдвижение меню
// 		$('.content').toggleClass('content-active'); // Сдвиг страницы
// 		$('footer').toggleClass('content-active');// $('body').toggleClass('blocking-block');//Фиксированное позиционирование боди
// 		// Cross animation
// 		$('.sandwich-main').toggleClass('sandwich-main-aktive');
// 		$('.sandwich-top').toggleClass('sandwich-top-aktive');
// 		$('.sandwich-bottom').toggleClass('sandwich-bottom-aktive');
// 		e.preventDefault();
// 	});

// $('.test-app').bind('click', function(){
// 	$('html').toggleClass('no');
// })

window.sr = ScrollReveal();

sr.reveal('.card1', {
	delay: 200,
	origin: 'bottom',
	distance: '80px',
	duration: 1000,
	interval: 600,
});
sr.reveal('.card2', {
	delay: 400,
	origin: 'bottom',
	distance: '80px',
	duration: 1000,
	interval: 600,
});
sr.reveal('.card3', {
	delay: 600,
	origin: 'bottom',
	distance: '80px',
	duration: 1000,
	interval: 600,
});




});





//   alert("dhf");
// $("#rrr").on("click", function(){
//     alert("The paragraph was clicked.");
// }); 



// wow = new WOW(
//     {
//         // boxClass:     'wow',      // default
//         // animateClass: 'animated', // default
//         // offset:       0,          // default
//         // mobile:       true,       // default
//         // live:         true        // default
//     })
// wow.init();
