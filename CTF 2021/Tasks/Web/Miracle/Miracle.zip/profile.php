<?php
session_start();
require 'vendor/autoload.php';
require 'FlashMessages.php';
$msg = new \Plasticbrain\FlashMessages\FlashMessages();
$client = new MongoClient("mongodb://localhost:27017");
$collection = $client->rts->offers;
$myoffers = $collection->find(array('seller' => $_SESSION['username']));
if(isset($_POST['action']) && $_POST['action']==='remove') {

  $collection->remove(array('item_name' => $_POST['item_name'], 'seller' => $_SESSION['username']));
}
if(isset($_SESSION['username']))
{
  if(isset($_FILES['photo'])) {
    $client = new MongoClient("mongodb://localhost:27017");
    $collection = $client->rts->offers;
    // $fileType = $_FILES['photo']['type'];
    // $fileContent = file_get_contents($_FILES['photo']['tmp_name']);
    $fileInfo = PATHINFO($_FILES["photo"]["name"]);

    if ($fileInfo['extension'] == "jpg" && filesize($_FILES['photo']['tmp_name'])<=1024*1024) {
      $newFilename = time(). "_" . rand(0, 100) . "." . $fileInfo['extension'];
      move_uploaded_file($_FILES["photo"]["tmp_name"], "uploads/" . $newFilename);
      $location = "uploads/" . $newFilename;
      $item = array(
        'location' => $location,
        'price' => $_POST['price'],
        'item_name' => $_POST['name'],
        'description' => $_POST['description'],
        'seller' => $_SESSION['username']
      );

      $temp = $collection->findOne(array('item_name' => $_POST['name']));
      if(empty($temp)) {
        $collection->insert($item);

        $msg->success('Your offer successfully uploaded.');
        $msg->display();
      } else {
        $msg->error('Item with such name already exists. Try another one.');
        $msg->display();
      }
    } else {
      $msg->error('Error: use jpg only and filesize=1Mb max!');
      $msg->display();
    }
  }

?>
<!DOCTYPE html>
<html lang="ru">
<head>
  <title>Profile</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <script src="js/libs.min.js" type="text/javascript"></script>
    <script src="js/createjs.min.js"></script>
    <script src="js/gsap.min.js"></script>
    <link id="callCss" rel="stylesheet" href="css/main.css" type="text/css" media="screen" charset="utf-8" />

</head>

<body>

  <header>
    <div class="container">
      <div class="row">
        <div class="col-3 center-logo">
          <a href="index.php"><h1 class="logo">Miracle</h1></a>
        </div>
        <div class="col-9 centering-nav">
            <ul class="nav justify-content-end">
                <li class="nav-item">
                  <a class="nav-link" href="index.php">Main</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="shop.php">Catalog</a>
                </li>
                                <li class="nav-item">
                  <a class="nav-link" href="profile.php">Profile</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="logout.php">Logout</a>
                </li>
                </ul>
        </div>
      </div>
    </div>
  </header>
<div class="wrapper">
  <div class="content">

<div class="shopMaim-block">
    <div class="profileMainblock">
        <div class="container">
      <div class="row">
        <div class="col-6">
          <div class="row">
              <div class="profileInf">
                  <div class="picture"></div>
                  <ul>
                    <li class="personName"><?php $new = htmlspecialchars($_SESSION['username']); echo $new; ?></li>
                    <li class="text-inProfile">Welcome. Sometimes it's not enough to just login. :)</li>
                  </ul>
                </div>
          </div>
          <div class="row">
            <h2 class="top-headerSell">Add your product here:</h2>
          </div>
          <div class="row">
              <form method="POST" enctype="multipart/form-data" class="sellProduct">

                  <div class="productParams">
                    <div class="common">
                        <div class="left">
                            <img id="img-uploaded" src="http://placehold.it/350x350" alt="your image" />
                        </div>
                              <div class="right">


                                <label class="file-wrapper">
                                    <input type="file" name="photo" accept="image/*" id="imgInp" class="uploader" required=""/>
                                  <span class="btn btn-large btn-alpha">Upload</span>
                                </label>
                              </div>
                    </div>
                    <div class="common">
                      <p class="productPrice ">Enter product price for 1 item/$</p>
                      <input class="priceInput" maxlength="9" name="price" type="text" required="">
                    </div>
                    <div class="common">
                      <p class="productPrice ">Enter product name</p>
                      <input class="priceInput" maxlength="32" name="name" type="text" required="">
                    </div>
                    <div class="common">
                      <p class="productPrice ">Description</p>
                      <textarea type="text"  maxlength="60" class="priceInput" name="description" value="" required=""></textarea>
                    </div>


                    <input class="customProdButn" type=submit value="Submit">
                  </div>
              </form>
          </div>
        </div>


        <div class="col-6">
          <div class="activity">
          <?php if(empty($collection->findOne(array('seller' => $_SESSION['username'])))) { ?>
            <h4>Your items will be displayed here.</h4>
          <?php } ?>
          <?php foreach($myoffers as $obj) { ?>
              <div class="transactions">
                <div class="container">
                  <div class="row">
                    <div class="col-2 transactions-init-centering">
                      <div class="transactions-img-wrap">
                        <img class="profile-img" src="<?php echo(htmlspecialchars(($obj['location']))); ?>">
                      </div>
                    </div>
                    <div class="col-4 transactions-init-centering">
                      <h4><?php $new = htmlspecialchars($obj['item_name']); echo $new;?></h4>
                    </div>
                    <div class="col-3 transactions-init-centering">
                      <div class="price"><?php $new = htmlspecialchars($obj['price']); echo $new; ?>$</div>
                    </div>
                    <div class="col-3 transactions-init-centering">
                      <form method="POST">
                        <input type="hidden" name="action" value="remove">
                        <input type="hidden" name="item_name" value="<?php echo (htmlspecialchars($obj['item_name'])); ?>">
                        <input class="customProdButn" type=submit value="Remove">
                      </form>
                    </div>
                  </div>
                </div>




              </div>
          <?php } ?>
          </div>
        </div>
      </div>
    </div>
    </div>

</div>


</div>


<script src="js/prekrasno.js" type="text/javascript"></script>
<script type="text/javascript">
  $(".close").click(function () {
    $( ".alert-success" ).addClass( "Closeclass" );
  })
</script>
</body>
</html>
<?php
}
else
{
  header('location: login.php');
}
?>
