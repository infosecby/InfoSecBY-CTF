<?php
  require 'vendor/autoload.php';
  require 'FlashMessages.php';
  session_start();
  if(isset($_SESSION['username'])) {
    header('location: profile.php');
  }
  $msg = new \Plasticbrain\FlashMessages\FlashMessages();
  if(isset($_POST['submit'])){
    $client = new MongoClient("mongodb://localhost:27017");
    $collection = $client->rts->users;
    $temp = $collection->findOne(array('username'=> $_POST['username']));
    if(empty($temp)){
      $post = array('username'     => $_POST['username'], 'password'   => $_POST['password'], 'email' => $_POST['email']);
      $collection->insert($post);
      header("location: login.php");
      exit;
    } else {
      $msg->error('Such username already exists.');
      $msg->display();
    }
  }
?>
<!DOCTYPE html>
<html lang="ru">
<head>
  <title>Registration page</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <script src="js/libs.min.js" type="text/javascript"></script>
    <script src="js/createjs.min.js"></script>
    <script src="js/gsap.min.js"></script>
  <link id="callCss" rel="stylesheet" href="css/main.css" type="text/css" media="screen" charset="utf-8" />
  <script src="js/libs.min.js" type="text/javascript"></script>
</head>

<body>

  <header>
    <div class="container">
      <div class="row">
        <div class="col-3 center-logo">
          <a href="index.php"><h1 class="logo">Miracle</h1></a>
        </div>
        <div class="col-9 centering-nav">
            <ul class="nav justify-content-end">
                <li class="nav-item">
                  <a class="nav-link" href="index.php">Main</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="shop.php">Catalog</a>
                </li>
                </ul>
        </div>
      </div>
    </div>
  </header>
<div class="wrapper">
  <div class="content">

<div class="shopMaim-block shopMaim-blockCentering shopingHeight">
    <form class="form-signin" method="POST">
        <h2 class="form-signin-heading">Create an account</h2>
        <input type="text" class="form-control" name="username" placeholder="Username " value="" required=""/>
        <input type="email" class="form-control" name="email" placeholder="Email Address" value="" required="" autofocus="" />
        <input type="password" class="form-control" name="password" placeholder="Password" value="" required=""/>
        <button class="stylesLoginBlock" type="submit" name="submit" value="submit">Register</button>
        <a href="login.php">Already have an account?</a>
      </form>
</div>


</div>



</body>
<script type="text/javascript">
</script>
<script src="js/prekrasno.js" type="text/javascript"></script>
</body>
</html>
