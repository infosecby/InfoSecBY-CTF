<?php
  require 'vendor/autoload.php';
  require 'FlashMessages.php';
  session_start();
  if(isset($_SESSION['username'])) {
    header('location: profile.php');
  }
  $msg = new \Plasticbrain\FlashMessages\FlashMessages();
  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $client = new MongoDB\Client("mongodb://localhost:27017");
    $collection = $client->rts->users;
    $user = $collection->find(array("username"=>$_POST['username'],"password"=>$_POST['password']));
    foreach($user as $obj)
    {
      $_SESSION['username'] = $obj['username'];
      header('location: profile.php');
    }
    $msg->error('Wrong credentials.');
    $msg->display();
  }
?>
<!DOCTYPE html>
<html lang="ru">
<head>
  <title>Login page</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <script src="js/libs.min.js" type="text/javascript"></script>
    <script src="https://code.createjs.com/1.0.0/createjs.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.1.1/gsap.min.js"></script>
    <link id="callCss" rel="stylesheet" href="css/main.css" type="text/css" media="screen" charset="utf-8" />
</head>

<body>

  <header>
    <div class="container">
      <div class="row">
        <div class="col-3 center-logo">
          <a href="index.php"><h1 class="logo">Miracle</h1></a>
        </div>
        <div class="col-9 centering-nav">
            <ul class="nav justify-content-end">
                <li class="nav-item">
                  <a class="nav-link" href="index.php">Main</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="shop.php">Catalog</a>
                </li>
                </ul>
        </div>
      </div>
    </div>
  </header>
<div class="wrapper">
  <div class="content">

<div class="shopMaim-block shopMaim-blockCentering shopingHeight">
    <form class="form-signin" method="POST">
        <h2 class="form-signin-heading">Login form</h2>
        <input type="text" class="form-control" name="username" placeholder="Username" value="" required="" autofocus="" />
        <input type="password" class="form-control" name="password" placeholder="Password" value="" required=""/>
        <label class="checkbox">
          <input type="checkbox" value="remember-me" id="rememberMe" name="rememberMe"> Remember me
        </label>
    <button class="stylesLoginBlock" type="submit" value="submit">Login</button>
    <a href="registration.php">Don't have an account?</a>
      </form>
</div>


</div>


<script type="text/javascript">
  $(".close").click(function () {
    $( ".alert-danger" ).addClass( "Closeclass" );
  })
</script>
<script
			  src="https://code.jquery.com/jquery-3.4.1.js"
			  integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU="
			  crossorigin="anonymous"></script>
        <script src="js/prekrasno.js" type="text/javascript"></script>
</body>
</html>
