<?php
  require 'vendor/autoload.php';
  session_start();
  $client = new MongoClient("mongodb://localhost:27017");
  $collection = $client->rts->offers;
  $temp = $collection->find();
  $array = array_reverse(iterator_to_array($temp));
  if(isset($_POST['submit'])) {
    if(isset($_SESSION['username'])) {
      $client2 = new MongoClient("mongodb://localhost:27017");
      $collection = $client2->rts->orders;
      $date = date('Y-m-d H:i:s');
      $order = array(
        'date' => $date,
        'address' => $_POST['address'],
        'phone_number' => $_POST['phone_number'],
        'name' => $_POST['name'],
        'additional_info' => $_POST['additional_info']
      );
      $collection->insert($order);
      header("location: shop.php");
    } else {
      header("location: login.php");
    }
  }
?>
<!DOCTYPE html>
<html lang="ru">
  <head>
    <title>shop</title>
    <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
          <meta name="author" content="">
            <script src="js/libs.min.js" type="text/javascript"></script>
            <script src="js/createjs.min.js"></script>
            <script src="js/gsap.min.js"></script>
            <link id="callCss" rel="stylesheet" href="css/main.css" type="text/css" media="screen" charset="utf-8" />
          </head>
          <body>
            <header>
              <div class="container">
                <div class="row">
                  <div class="col-3 center-logo">
                    <a href="index.php"><h1 class="logo">Miracle</h1></a>
                  </div>
                  <div class="col-9 centering-nav">
                    <ul class="nav justify-content-end">
                      <li class="nav-item">
                        <a class="nav-link" href="index.php">Main</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="shop.php">Catalog</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="profile.php">Profile</a>
                      </li>
                      <li class="nav-item"></li>
                      <?php if(isset($_SESSION['username'])){ ?>
                      <li class="nav-item">
                        <a class="nav-link" href="logout.php">Logout</a>
                      </li>
                      <?php } ?>
                      <div id="cartIcon" class="shopCart">
                        <div id="cart" class="cart-items">
                          <div class="total">
                            Total:

                            <span id="totalPrice">0 $</span>
                            <button class="AddToCart Order" id="rrr">Buy</button>
                          </div>
                        </div>
                        <div id="circle" class="cartPurchases">0</div>
                      </div>
                    </div>
                    <div class="totalPrice"></div>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </header>
        <!-- Order form -->
        <div class="mainorderform" id="mainorderform" >
          <!--   <div class="orderform"></div> -->
          <div class="shopMaim-blockCentering shopingHeight orderform">
            <form class="form-signin" method="POST">
              <h2 class="form-signin-heading">Make your order</h2>
              <input type="text" class="form-control" name="address" placeholder="Adress" value="" required="" autofocus="" />
              <input type="text" class="form-control" name="phone_number" placeholder="Phone_number" value="" required=""/>
              <input type="text" class="form-control" name="name" placeholder="Your name" value="" required=""/>
              <textarea type="text" class="form-control" name="additional_info" placeholder="Additional info" value="" required=""></textarea>
              <button class="stylesLoginBlock" type="submit" name="submit" value="submit">Confirm</button>
            </form>
          </div>
        </div>
       <!-- Order form END -->
        <div class="wrapper">
          <div class="content">

            <div class="main-background shopMaim-block">
              <div class="sellProducts">
                <div class="container">
                  <div class="row">
                    <?php foreach ($array as $obj) { ?>
                    <div class="col-sm-4 col-12 col-lg-3 centeringProducts">
                      <div class="product">
                        <h2 class="product-name">
                          <?php echo (htmlspecialchars($obj['item_name'])); ?>
                        </h2>
                        <img src="<?php echo(htmlspecialchars(($obj['location']))); ?>" alt="">
                        <h3>Seller:

                          <span class="seller">
                            <?php echo (htmlspecialchars($obj['seller'])); ?>
                          </span>
                        </h3>
                        <h3>Description:

                          <p class="description-item">
                            <?php echo (htmlspecialchars($obj['description'])); ?>
                          </p>
                        </h3>
                          <h3>Price:

                            <span>
                              <?php echo (htmlspecialchars($obj['price'])); ?>
                            </span>

                          </h3>
                          <h4>Choose count

                            <input class="kg" type="number" value="1" min="1" maxlength="2">
                            </h4>
                            <button class="AddToCart ventil">Add to Cart</button>
                          </div>
                        </div>
                        <?php
      }
      ?>
                        <div></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            </body>
            <!-- Wrapper end -->
            <script type="text/javascript">



$('.Order').click(function(e) {
    var items2 = document.getElementsByClassName('cartElement');
  for (var i = 0; i
              <items2.length; i++) {
    console.log("heh");
  }
    $('.mainorderform').toggleClass('mainorderformMain');
  e.stopPropagation();
  $('body').toggleClass('mainorderformMainforBody');
  e.stopPropagation();
});

$('.orderform').click(function(e) {
    if ($(e.target).is('.orderform')) {
        $('.mainorderform').removeClass('mainorderformMain');
        $('body').removeClass('mainorderformMainforBody');

    }
});




              </script>
              <script src="js/prekrasno.js" type="text/javascript"></script>
            </body>
          </html>
